package de.kai_morich.simple_usb_terminal;

public class rgLoc {
    public static String ret = "";
    public static double longi;
    public static double lati;
    public static double bearing;
    public static double speed;
    public static double alti;
}
